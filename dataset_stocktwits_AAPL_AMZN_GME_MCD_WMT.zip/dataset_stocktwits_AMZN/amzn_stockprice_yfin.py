from pandas_datareader import data as pdr
import pandas as pd
import yfinance as yf
yf.pdr_override()

ticker = "AMZN"
# AMZN = yf.Ticker(ticker)
# hist = AMZN.history(period="1y")

data = pdr.get_data_yahoo(ticker, start="2019-06-20", end = "2021-04-02")
df = pd.DataFrame(data)
# path_dir: str = r"C:\Users\marcu\OneDrive\Desktop\419 PROJECT"
# df.to_csv(path_dir)

for temp in df:
    for value in temp:
        print(value)